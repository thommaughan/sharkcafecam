msp430_i2cEEPROM
================

Skeleton framework for reading and writing from a  24AAxx I2C EEPROM chip for MSP430 Launchpad/MSP430g2553

Pinout for the launchpad - P1.6 = SCL; P1.7 = SDA
